#include<stdio.h>
int main()
{
    int n, i;
    printf("Enter N=");
    scanf("%d", &n);

     for(i = 1; i <= n; i++)s
     {
         printf("%d", i);
     }
}

