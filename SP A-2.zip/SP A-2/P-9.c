#include <stdio.h>

int main()
{
    int n, i;
    unsigned long long factorial = 1;

    printf("Enter N (0 to 20): ");
    scanf("%d", &n);

    if (n < 0 || n > 20)
    {
        printf("Enter a number from 0 to 20.\n");
        return 1;
    }

    for (i = 1; i <= n; i++)
    {
        factorial = factorial * i;
    }

    printf("Factorial = %llu\n", factorial);
}
