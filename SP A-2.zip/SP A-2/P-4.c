#include<stdio.h>
int main()
{
    int n, i;
    int sum=0;
     printf("Enter N=");
     scanf("%d", &n);

     for (i=2; i<=n; i+=2)
     {
         sum= sum+i;

     }
     printf("sum of even number=%d\n", sum);
}
